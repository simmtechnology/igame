package org.devtest.devtest;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@RestController
public class Conversion {
	public static final double MILES_AND_KM= 0.62137119;
	public static final double CELSIUS_AND_KELVIN=273.15;
	@Produces(MediaType.APPLICATION_JSON + ";charset=UTF-8")
	@RequestMapping(value="/conversions/ctok/{celcius}",method=RequestMethod.GET)
	public String ctok(@PathVariable ("celcius") double celcius) 
	{
		JSONObject obj=new JSONObject();
		Double kelvin= celcius+CELSIUS_AND_KELVIN;
		try {
			obj.put("units","kelvin");
			obj.put("value",kelvin);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return obj.toString();
	}
	
	@Produces(MediaType.APPLICATION_JSON + ";charset=UTF-8")
	@RequestMapping(value="/conversions/ktoc/{kelvin}",method=RequestMethod.GET)
	public String ktoc(@PathVariable ("kelvin") double kelvin) 
	{
		JSONObject obj=new JSONObject();
		Double celcius= kelvin-CELSIUS_AND_KELVIN;
		try {
			obj.put("units","Celcius");
			obj.put("value",celcius);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return obj.toString();
	}
	@Produces(MediaType.APPLICATION_JSON + ";charset=UTF-8")
	@RequestMapping(value="/conversions/mtok/{miles}",method=RequestMethod.GET)
	public String mtok(@PathVariable ("miles") double miles) 
	{
		JSONObject obj=new JSONObject();
		Double km= miles * MILES_AND_KM;
		try {
			obj.put("units","km");
			obj.put("value",km);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return obj.toString();
	}
	
	@Produces(MediaType.APPLICATION_JSON + ";charset=UTF-8")
	@RequestMapping(value="/conversions/ktom/{km}",method=RequestMethod.GET)
	public String ktom(@PathVariable ("km") double km) 
	{
		JSONObject obj=new JSONObject();
		Double miles= km/MILES_AND_KM;
		try {
			obj.put("units","miles");
			obj.put("value",miles);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return obj.toString();
	}
}
