package za.test.game;

public class Bet {
	String player;
	String betNumber;
	double betAmount;
	String resultsOfBet;
	public String getResultsOfBet() {
		return resultsOfBet;
	}
	public void setResultsOfBet(String resultsOfBet) {
		this.resultsOfBet = resultsOfBet;
	}
	public String getPlayer() {
		return player;
	}
	public void setPlayer(String player) {
		this.player = player;
	}
	public String getBetNumber() {
		return betNumber;
	}
	public void setBetNumber(String betNumber) {
		this.betNumber = betNumber;
	}
	public double getBetAmount() {
		return betAmount;
	}
	public void setBetAmount(double betAmount) {
		this.betAmount = betAmount;
	}
	@Override
	public String toString() {
		return "Bet [player=" + player + ", betNumber=" + betNumber + ", betAmount=" + betAmount + ", resultsOfBet="
				+ resultsOfBet + "]";
	}
	
	

}
