package za.test.game;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MygameApplicationTests {

	@Test
	void contextLoads() {
	}

}
